[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)


# 🤖 GuMusic (Discord Music Bot)
> GuMusic e um bot de música.
<a href="https://discord.com/oauth2/authorize?client_id=902560677867175987&scope=bot&permissions=36701696">Clique  aqui para convidar o bot.</a>
